package com.example.freefiretraining

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("training", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(9,9,9))
            setPadding(24, 28, 24, 24)
        }
    }

    private fun title(text: String, size: Float = 26f): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 14)
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.rgb(255,179,0))
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-1, 56).apply { setMargins(0,8,0,8) }
        }

    private fun card(text: String): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(23,23,23))
            setPadding(20,18,20,18)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,6,0,6) }
        }

    private fun showHome() {
        root = base()
        root.addView(title("🎯 HEADSHOT TRAINING"))
        root.addView(card("Legit Free Fire companion\n\nPractice aim, save sensitivity presets, and track your training.\n\nThis app does not control, inject into, or modify the game."))
        root.addView(button("🎯 Training Drills") { showDrills() })
        root.addView(button("⚙ Sensitivity Presets") { showSensitivity() })
        root.addView(button("📊 Session Tracker") { showTracker() })
        root.addView(button("ℹ About") { showAbout() })
        setContentView(root)
    }

    private fun showDrills() {
        root = base()
        root.addView(title("🎯 TRAINING DRILLS"))
        val drills = listOf(
            "1. Drag-shot drill — 5 minutes\nStart at chest level and smoothly drag toward the head.",
            "2. Flick drill — 5 minutes\nMove between targets and practice short controlled flicks.",
            "3. Recoil control — 5 minutes\nPractice keeping your crosshair stable during sustained fire.",
            "4. One-tap precision — 5 minutes\nFocus on timing rather than spraying."
        )
        drills.forEach { root.addView(card(it)) }
        root.addView(button("Start 20-minute session") {
            prefs.edit().putInt("sessions", prefs.getInt("sessions",0)+1).apply()
            Toast.makeText(this, "Session recorded!", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("← Back") { showHome() })
        setContentView(root)
    }

    private fun showSensitivity() {
        root = base()
        root.addView(title("⚙ SENSITIVITY PRESETS"))
        val names = arrayOf("Balanced", "Drag Shot", "Low Sensitivity")
        val values = arrayOf("General 90 | Red Dot 85 | 2x 75 | 4x 65 | Sniper 50",
                              "General 95 | Red Dot 90 | 2x 80 | 4x 70 | Sniper 55",
                              "General 75 | Red Dot 70 | 2x 65 | 4x 55 | Sniper 40")
        for (i in names.indices) {
            root.addView(card("${names[i]}\n${values[i]}"))
            root.addView(button("Save ${names[i]}") {
                prefs.edit().putString("preset", names[i]).apply()
                Toast.makeText(this, "${names[i]} saved", Toast.LENGTH_SHORT).show()
            })
        }
        root.addView(button("← Back") { showHome() })
        setContentView(root)
    }

    private fun showTracker() {
        root = base()
        root.addView(title("📊 SESSION TRACKER"))
        val sessions = prefs.getInt("sessions", 0)
        val preset = prefs.getString("preset", "None")
        root.addView(card("Training sessions completed: $sessions\n\nCurrent preset: $preset"))
        root.addView(button("Reset session count") {
            prefs.edit().putInt("sessions",0).apply()
            showTracker()
        })
        root.addView(button("← Back") { showHome() })
        setContentView(root)
    }

    private fun showAbout() {
        root = base()
        root.addView(title("ℹ ABOUT"))
        root.addView(card("Headshot Training Companion v1.0\n\nBuilt for practice and personal settings management.\n\nNo aimbot, auto-headshot, memory editing, screen automation, or game injection is included."))
        root.addView(button("← Back") { showHome() })
        setContentView(root)
    }
}
